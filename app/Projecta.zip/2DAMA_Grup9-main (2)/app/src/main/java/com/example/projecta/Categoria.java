package com.example.projecta;

public class Categoria {
    String idCategoria;
    String nomCategoria;
    public Categoria(String idCategoria,String nomCategoria) {
        this.idCategoria =idCategoria;
        this.nomCategoria = nomCategoria;
    }

}

