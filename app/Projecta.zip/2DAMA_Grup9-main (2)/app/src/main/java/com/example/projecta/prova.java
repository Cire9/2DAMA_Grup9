package com.example.projecta;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class prova extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.prova);
    }
}